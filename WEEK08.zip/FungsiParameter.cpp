#include <iostream>
using namespace std;

int tambah(int a, int b) {
    return a + b;
}

int kurang(int a, int b) {
    return a - b;
}

int kali(int a, int b) {
    return a * b;
}

float bagi(int a, int b) {
    if (b == 0) {
        cout << "Error: tidak bisa dibagi 0!" << endl;
        return 0;
    }
    return (float)a / b;
}

int main() {
    int x, y;
    char op;

    cout << "=== KALKULATOR ===" << endl;
    cout << "Masukkan angka pertama : ";
    cin >> x;
    cout << "Masukkan operator (+,-,*,/) : ";
    cin >> op;
    cout << "Masukkan angka kedua   : ";
    cin >> y;

    cout << x << " " << op << " " << y << " = ";

    if      (op == '+') cout << tambah(x, y) << endl;
    else if (op == '-') cout << kurang(x, y) << endl;
    else if (op == '*') cout << kali(x, y)   << endl;
    else if (op == '/') cout << bagi(x, y)   << endl;
    else cout << "Operator tidak valid!" << endl;

    return 0;
}