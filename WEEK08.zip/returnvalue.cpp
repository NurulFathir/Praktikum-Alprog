#include <iostream>
using namespace std;

/** Definisi fungsi sebut_nama()
 *  Bertipe data string, tanpa parameter
 *  Mengembalikan "Joko"
 */
string sebut_nama() {
    string nama = "Joko";
    return nama;
}

/** Definisi fungsi umur()
 *  Bertipe data integer, tanpa parameter
 *  Mengembalikan bilangan bulat 4
 */
int umur() {
    return 4;
}

int main() {
    // Memanggil fungsi sebut_nama() dan menyimpan nilai kembalianya
    // ke variabel namaku yang bertipe sama dengan fungsi sebut_nama()
    string namaku = sebut_nama();

    // Menampilkan variabel nama
    cout << "Halo, saya " << namaku;

    // Memanggil variabel umur dan langsung menampilkan nilai kembalinya
    cout << " dan umur saya " << umur() << " tahun." << endl;

    return 0;
}