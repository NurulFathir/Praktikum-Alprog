#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>
using namespace std;

/** Definisi fungsi undian()
 *  Bertipe data integer, tanpa parameter
 *  Mengembalikan bilangan bulat antara 1 sampai 25 secara acak
 */
int undian() {
    return ((rand() % 25) + 1);
}

int main() {
    // Mengatur seed untuk perhitungan angka acak menggunakan waktu saat ini
    srand(time(NULL));

    cout << "Tekan tombol apa saja untuk melempar undian, tekan 'q' untuk keluar." << endl;

    // Variabel counter kocokan
    int kocokan = 0;

    // Selama karakter yang ditekan bukan 'q', terus lakukan perulangan
    while (getch() != 'q') {
        // Memanggil fungsi undian() kemudian tampilkan
        cout << "\nNomor undian Anda: " << undian();

        // Sudah berapa kali melempar undian?
        cout << " (Kocokan ke-" << ++kocokan << ")";
    }

    // Program mencapai baris ini setelah program keluar dari
    // blok perulangan while (karena user menekan 'q')

    // No more things to do. Exit program with style
    return 0;
}