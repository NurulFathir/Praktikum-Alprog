#include <iostream>
using namespace std;

/** Definisi fungsi sapaan().
 *  Bertipe data void, tanpa parameter.
 *  Mencetak "Halo warga tembalang!".
 */
void sapaan() {
    cout << "Halo warga tembalang!" << endl;
}

int main() {
    // Memanggil fungsi sapaan()
    sapaan();
    return 0;
}