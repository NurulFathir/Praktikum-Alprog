#include <iostream>
using namespace std;

void sapaan(); // Deklarasi fungsi sapaan()

int main() {
    // Memanggil fungsi sapaan()
    sapaan();
    return 0;
}

/** Definisi fungsi sapaan()
 *  Bertipe data void, tanpa parameter
 *  Mencetak "Halo warga tembalang!"
 */
void sapaan() {
    cout << "Halo warga tembalang!" << endl;
}