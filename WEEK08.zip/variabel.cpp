#include <iostream>
using namespace std;

// Deklarasi variabel global jam dan sisa_menit sebagai integer
int jam, sisa_menit;

/** Definisi fungsi konversi(int, int)
 *  Bertipe data void, dengan parameter (int total_menit, int menit_perjam)
 *  Menghitung jam dan sisa menit
 *  dimana total_menit = jam * menit_perjam + sisa_menit
 *  dimana jam dan sisa_menit sudah dideklarasikan secara global
 */
void konversi(int total_menit, int menit_perjam) {
    jam         = total_menit / menit_perjam; // Berapa jam penuhnya
    sisa_menit  = total_menit % menit_perjam; // Sisa menit yang tidak genap 1 jam
}

int main() {
    // Deklarasikan variabel lokal x dan y sebagai integer
    int x, y;

    cout << "Total menit  : ";
    cin >> x;
    cout << "Menit per jam: ";
    cin >> y;

    // Memanggil fungsi konversi() dengan x dan y sebagai argumen
    konversi(x, y);

    // Mencatat hasilnya
    cout << x << " menit = " << jam << " jam " << sisa_menit << " menit" << endl;

    return 0;
}