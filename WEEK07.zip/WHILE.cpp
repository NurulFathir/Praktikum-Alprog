#include <iostream>
using namespace std;

int main()
{
    int i = 1;
    while (i <= 12) {
        cout << "Perulangan ke-" << i << endl;
        i++; 
    }
    
    return 0;
}