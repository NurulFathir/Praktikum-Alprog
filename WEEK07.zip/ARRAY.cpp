#include <iostream>
using namespace std;

int main() 
{
    // Deklarasi array 1 dimensi dengan 5 elemen bertipe double
    double balance[5] = {1250.0, 5.0, 1.4, 13.0, 65.0};

    cout << "--- Isi awal array balance ---" << endl;
    for(int i = 0; i < 5; i++) {
        cout << "balance[" << i << "] = " << balance[i] << endl;
    }

    // Mengubah nilai elemen array indeks ke-4 (elemen ke-5)
    balance[4] = 99.9;
    
    cout << "\n--- Setelah balance[4] diubah ---" << endl;
    cout << "balance[4] = " << balance[4] << endl;

    return 0;
}