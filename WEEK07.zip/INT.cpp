#include <iostream>
using namespace std;

int main()
{
    int a, b;
    int hasil;
    
    cout << "masukkan nilai a: ";
    cin >> a;
    cout << "masukkan nilai b: ";
    cin >> b;
    
    a = a - b;
    hasil = a + 3;
    
    cout << "tampilkan a: " << a << endl;
    cout << "tampilkan hasil: " << hasil << endl;
    
    return 0;
}