#include <iostream>
using namespace std;

int main()
{
    string nama;
    string nim;

    cout << "Masukkan nama mahasiswa: ";
    cin >> nama;
    cout << "Masukan NIM anda: ";
    cin >> nim;

    cout<< "Nama Anda adalah: " << nama << endl;
    cout<< "NIM Anda adalah: " << nim << endl;
    return 0;
}