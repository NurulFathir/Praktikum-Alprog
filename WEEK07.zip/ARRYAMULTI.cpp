#include <iostream>
using namespace std;

int main() 
{
    // Deklarasi array 2 dimensi (matriks 5 baris, 3 kolom)
    int n[5][3] = {
        {3, 5, 1},
        {4, 4, 8},
        {1, 3, 4},
        {3, 2, 2},
        {9, 1, 3}
    };

    cout << "--- Isi Array Matriks n[5][3] ---" << endl;
    
    // Perulangan luar untuk mencetak baris
    for(int baris = 0; baris < 5; baris++) {
        // Perulangan dalam untuk mencetak kolom
        for(int kolom = 0; kolom < 3; kolom++) {
            cout << n[baris][kolom] << "  ";
        }
        cout << endl; // Pindah baris (enter) setelah 3 kolom tercetak
    }

    return 0;
}