#include <iostream>
using namespace std;

int main() 
{
    int kecepatan;
    cout << "Masukkan kecepatan kendaraan anda =  ";
    cin >> kecepatan;
    
    if (kecepatan >= 100) {
        cout << "Maaf anda melanggar aturan lalu lintas" << endl;
    } else {
        cout << "Kecepatan kendaraan anda aman, selamat berkendara" << endl;
    }
    
    return 0;
}