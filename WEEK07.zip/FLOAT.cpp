#include <iostream>
using namespace std;
 
int main()
{
    float kg, gram, pound, ons;
    
    cout << "Masukkan Berat Dalam Kilogram = ";
    cin >> kg;
    cout << endl;
    
    // proses konversi berat
    gram  = kg * 1000;
    pound = kg * 2.20462;
    ons   = kg * 35.274;
    
    cout << "Berat dalam Gram  = " << gram  << " Gram"  << endl;
    cout << "Berat dalam Pound = " << pound << " Pound" << endl;
    cout << "Berat dalam Ons   = " << ons   << " Ons"   << endl;
    cout << endl;
    
    return 0;
}
 