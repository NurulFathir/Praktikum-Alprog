#include <iostream>
using namespace std;

int main() 
{
    // Cara 1: Deklarasi per karakter tunggal (wajib diakhiri '\0')
    char greeting1[8] = {'M', 'o', 'r', 'n', 'i', 'n', 'g', '\0'};
    
    // Cara 2: Deklarasi string literasi langsung (kompiler otomatis menambahkan '\0')
    char greeting2[] = "Good Night";

    cout << "--- Membandingkan Pembuatan String ---" << endl;
    cout << "Output array greeting1 : " << greeting1 << endl;
    cout << "Output array greeting2 : " << greeting2 << endl;

    return 0;
}