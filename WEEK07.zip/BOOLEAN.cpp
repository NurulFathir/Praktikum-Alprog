#include <iostream>
using namespace std;

int main()
{
    int umur;
    bool status_sim;
    
    cout << "Masukkan jumlah sks = ";
    cin >> umur;
    
    // Logika: bernilai 1 (True) jika umur 17 atau lebih, dan 0 (False) jika di bawah 17
    status_sim = umur >= 17; 
    
    if (status_sim) {
        cout << "Memenuhi syarat kelulusanm" << endl;
    } else {
        cout << "Tidak memenuhi syarat kelulusan"<< endl;
    }
    
    return 0;
}