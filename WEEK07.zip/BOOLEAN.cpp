#include <iostream>
using namespace std;

int main()
{
    int sks;
    bool status_kelulusan;
    
    cout << "Masukkan jumlah sks = ";
    cin >> sks;
    
    // Logika: bernilai 1 (True) jika sks 140 atau lebih, dan 0 (False) jika di bawah 120
    status_kelulusan = sks >= 140; 
    
    if (status_kelulusan) {
        cout << "Memenuhi syarat kelulusan" << endl;
    } else {
        cout << "Tidak memenuhi syarat kelulusan"<< endl;
    }
    
    return 0;
}