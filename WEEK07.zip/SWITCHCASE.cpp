#include <iostream>
using namespace std;

int main()
{
    int kode;
    cout << "Masukkan Kode Jurusan [1/2/3]: "; 
    cin >> kode;
    
    switch (kode)
    {
        case 1:
            cout << "Pertanian";
            break;
        case 2:
            cout << "Akuntansi";
            break;
        case 3:
            cout << "Sastra Indonesia";
            break;
        default:
            cout << "Kode tidak ditemukan";
            break;
    }
    
    return 0;
}