#include <iostream> 
using namespace std; 

int main() 
{
    cout << "Hari ini praktikum modul 7 alprog"; 
    return 0;
}