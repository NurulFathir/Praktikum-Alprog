#include <iostream>
using namespace std;

int main()
{
    string nama;
    cout << "Masukan nama hewan peliharaan anda = ";
    cin >> nama;
    
    char ch = nama[0];
    char ch1 = nama[1];
    
    cout << "huruf pertama dari nama hewan peliharaan anda adalah " << ch << endl;
    cout << "huruf kedua dari nama hewan peliharaan anda adalah " << ch1 << endl;
    
    return 0;
}